<template>
  <div id="app">
      <el-container>
          <el-header class="header" >
              <el-row :gutter="20">
                  <el-col :span="8">
                      <div class="label-wrap">
                          <label for="">label</label>
                          <div class="wrap-content" >
                            <el-button type="Primary" :disabled="isDisabled">批量删除</el-button>
                            <el-button type="Primary" :disabled="isDisabled">批量删除</el-button>
                          </div>
                      </div>

                  </el-col>
                  <el-col :span="16">
                      <span> {{ $t("lang.home")}}</span>
                      <span @click="change()">切换</span>
                  </el-col>
                  <el-col :span="4"> &nbsp; </el-col>
              </el-row>
          </el-header>
          <el-main >
              <MyTable  :table_data="tableData" />
              <div style="margin-top: 20px">
                  <el-button @click="toggleSelection([tableData[1], tableData[2]])">切换第二、第三行的选中状态</el-button>
                  <el-button @click="toggleSelection()">取消选择</el-button>
              </div>
          </el-main>
      </el-container>
  </div>
</template>

<script>
// import HelloWorld from './components/HelloWorld.vue'
import MyTable from '@/components/MyTable.vue';
export default {
    name: 'App',
    components: {
          MyTable
      },
    data() {
      return {
          lang:'zh',
          isDisabled: true,
          tableData: [
          {
              date: '2016-05-06',
              name: '王小虎',
              address: '上海市普陀区金沙江路 1518 弄上海市普陀区金沙江路 1518 弄上海市普陀区金沙江路 1518 弄上海市普陀区金沙江路 1518 弄上海市普陀区金沙江路 1518 弄'
          }, {
              date: '2016-05-07',
              name: '王小虎',
              address: '上海市普陀区金沙江路 1518 弄'
          }],
          multipleSelection: [],
      }
    },
    methods: {
        change() {
          let lang = this.$i18n.locale === 'zh' ? 'en':'zh'
          this.$i18n.locale = lang
        },
        toggleSelection(rows) {
            if (rows) {
                rows.forEach(row => {
                    this.$refs.multipleTable.toggleRowSelection(row);
                });
            } else {
                this.$refs.multipleTable.clearSelection();
            }
        },
    }
}
</script>

<style lang="scss" scoped>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

.header {
    line-height: 60px;
    height: 60px;
    background-color: #ccc;
}

.label-wrap {
    label {
        float: left;
    }
    .wrap-content {
        text-align: left;
        padding-left: 10px;
        margin-left: 40px;
        //background-color: yellow;
    }
}

</style>
