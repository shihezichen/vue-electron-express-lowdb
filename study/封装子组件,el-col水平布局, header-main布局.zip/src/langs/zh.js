export const lang = {
    home :'首页',
    name: '中文'
}