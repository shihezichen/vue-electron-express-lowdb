export const lang = {
    home :'home',
    name: 'english'
}